This is the folder where the leaf emojis are stored

Please do not make any emoji over 16x16 (or 48x11 for rank icons)

The .xcf files have been provided in this folder, they are the project files for gimp.